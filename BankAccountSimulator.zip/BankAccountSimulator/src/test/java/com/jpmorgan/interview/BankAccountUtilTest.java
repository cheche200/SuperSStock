package com.jpmorgan.interview;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Test;

import com.jpmorgan.interview.controller.util.BankAccountUtil;

public class BankAccountUtilTest {

	@Test
	public void testHaveEnoughBalance() {
		assertEquals(true, BankAccountUtil.haveFunds(new BigDecimal("2000"), "200"));
	}
	
	@Test
	public void testSubstractBalance(){
		assertEquals(new BigDecimal(180), BankAccountUtil.substractFunds(new BigDecimal("200"),"20"));
	}
	
	@Test
	public void testAddBalance(){
		assertEquals(new BigDecimal(220), BankAccountUtil.addFunds(new BigDecimal("200"),"20"));
	}

}
