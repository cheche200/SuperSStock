package com.jpmorgan.interview;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import org.junit.BeforeClass;
import org.junit.Test;

import com.jpmorgan.interview.controller.BankAccountController;
import com.jpmorgan.interview.exception.AccountOverDraftException;
import com.jpmorgan.interview.model.BankAccount;

public class BankAccountControllerTest {
	private static BankAccount testAccount;
	private static BankAccountController accountController;
	
	@BeforeClass
	public static void beforeClass(){
		testAccount = new BankAccount("A123456",new BigDecimal("200"));
	    accountController = new BankAccountController();
	}
	
	@Test
	public void testCreateAccount() {
		assertEquals(testAccount, accountController.createAccount("A123456", "200"));
	}

	@Test(expected = AccountOverDraftException.class)
	public void testAccountOverDraftException() throws AccountOverDraftException{	
			accountController.doDepositOverDraft(testAccount, testAccount, "300");      
	}
	
	@Test
	public void testDoDepositOverDraft() throws AccountOverDraftException{
		    testAccount.setOverDraftLimit(new BigDecimal(400));
		    accountController.doDepositOverDraft(testAccount, testAccount, "300");
	}
	

}




