package com.jpmorgan.interview.exception;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class AccountOverDraftException extends Exception {
	
	static Logger logger = Logger.getLogger(AccountOverDraftException.class);
			
		public AccountOverDraftException(String message) {
	        super(message);
	        logger.error(message);
		}  
	    
}
