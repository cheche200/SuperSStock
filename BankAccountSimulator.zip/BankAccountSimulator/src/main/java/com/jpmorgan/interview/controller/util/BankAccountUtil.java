package com.jpmorgan.interview.controller.util;

import java.math.BigDecimal;


public class BankAccountUtil {

	public static boolean haveFunds(BigDecimal accountSource, String ammount) {		
		return accountSource.compareTo(new BigDecimal(ammount)) > 0 ? true : false;	
	}
	
	public static BigDecimal substractFunds(BigDecimal balance, String ammount){
		return balance.subtract(new BigDecimal(ammount));
	}

	public static BigDecimal addFunds(BigDecimal targetBalance, String ammount) {		
		return targetBalance.add(new BigDecimal(ammount));
	}
	
	

}
