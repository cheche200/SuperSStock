package com.jpmorgan.interview;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jpmorgan.interview.controller.Accountable;
import com.jpmorgan.interview.controller.BankAccountController;
import com.jpmorgan.interview.model.BankAccount;

public class SimulatedBankAccounts {

	
	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/jpmorgan/interview/config/beans.xml");
		Map<String,BankAccount> bankAccountMap = new HashMap<String,BankAccount>();
		Accountable accountController = (BankAccountController) context.getBean("AccountController");
		BatchInput batchInput = new BatchInput();
		String line;
		
		while ((line=batchInput.nextInputLine())!=null){
			
			//System.out.println(line);
			String[] batch = line.split("\\s+");
			
			switch (batch[0]){
			case "createAccount":
				bankAccountMap.put(batch[1],(BankAccount) accountController.createAccount(batch[1],batch[2]));
				break;
			
			case "transfer":
				accountController.transferAccount(bankAccountMap.get(batch[1]),bankAccountMap.get(batch[2]),batch[3]);
				break;
			
			case "addOverdraft":
				accountController.addOverdraft(bankAccountMap.get(batch[1]),batch[2]);
				break;
			
			case "exit":
				break;
			}
			
		}
		
		printOutAccountBalancesToScreen(bankAccountMap);
		((ClassPathXmlApplicationContext)context).close();
	}

	private static void printOutAccountBalancesToScreen(Map<String, BankAccount> bankAccountMap) {
		
		for(Map.Entry<String, BankAccount> entry : bankAccountMap.entrySet()){
			System.out.println(entry.getValue()+" - Balance:"+entry.getValue().getBalance());
		}
		
	}

	

	

}
