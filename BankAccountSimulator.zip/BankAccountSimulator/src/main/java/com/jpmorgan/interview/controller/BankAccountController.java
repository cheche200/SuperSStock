package com.jpmorgan.interview.controller;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.jpmorgan.interview.controller.util.BankAccountUtil;
import com.jpmorgan.interview.exception.AccountOverDraftException;
import com.jpmorgan.interview.model.BankAccount;
/**
 * 
 * @author Jose Calderon
 * 
 * This is the controller for BankAccount
 *
 */
@Component("AccountController")
public class BankAccountController implements Accountable {
    /**
     * 
     * @param accountNumber number of the bank account 
     * @param balance initial account balance
     * @return the new Bank Account
     */
	
	private static Logger logger = Logger.getLogger(BankAccountController.class);
	
	public BankAccount createAccount(String accountNumber, String balance) {
		logger.debug("Creating account: ****"+accountNumber.substring(accountNumber.length() -3)+" with balance: "+balance);
		return new BankAccount(accountNumber,new BigDecimal(balance));
		
	}
    
	/**
	 * 
	 * @param accountSource bank account where funds will be withdrew
	 * @param accountTarget bank account where the funds will be transfer
	 * @param ammount quantity to be transfer
	 */
	public void transferAccount(BankAccount accountSource, BankAccount accountTarget, String ammount) {
	
		if(BankAccountUtil.haveFunds(accountSource.getBalance(),ammount)){
			doDeposit(accountSource,accountTarget,ammount);
		}else{
			try{
				doDepositOverDraft(accountSource,accountTarget,ammount);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 
	 * @param accountSource bank account where funds will be withdrew
	 * @param accountTarget bank account where the funds will be transfer
	 * @param ammount quantity to be transfer
	 * @throws AccountOverDraftException in case there is no Over Draft limit available
	 */
    public void doDepositOverDraft(BankAccount accountSource, BankAccount accountTarget, String ammount) throws AccountOverDraftException {
		if(BankAccountUtil.haveFunds(accountSource.getOverDraftLimit(), ammount)){
			doDeposit(accountSource, accountTarget, ammount);
			logger.debug("Thasfer made using Over Draft funds.");
		}else{
			throw new AccountOverDraftException("ERROR: The "+accountSource+" does not have the available funds to perform the requested transfer.");
		}
		
	}
    /**
	 * 
	 * @param accountSource bank account where funds will be withdrew
	 * @param accountTarget bank account where the funds will be transfer
	 * @param ammount quantity to be transfer
	 */
	public void doDeposit(BankAccount accountSource, BankAccount accountTarget, String ammount) {
    	accountSource.setBalance(BankAccountUtil.substractFunds(accountSource.getBalance(), ammount));
		accountTarget.setBalance(BankAccountUtil.addFunds(accountTarget.getBalance(), ammount));	
		logger.debug("Transfer of "+ammount+" success from: "+accountSource+" to: "+accountTarget);
	}


	/**
     * 
     * @param bankAccount account to be increased the overdraft limit
     * @param ammount authorized overdraft limit
     */
	public void addOverdraft(BankAccount bankAccount, String ammount) {
		bankAccount.setOverDraftLimit(new BigDecimal(ammount));
		logger.debug("The overdraft limit for the account "+bankAccount+" was updated to: "+ammount);
	}

}
