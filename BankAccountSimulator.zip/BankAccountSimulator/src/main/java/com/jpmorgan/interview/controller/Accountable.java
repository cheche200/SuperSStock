package com.jpmorgan.interview.controller;

import com.jpmorgan.interview.model.Account;
import com.jpmorgan.interview.model.BankAccount;

public interface Accountable {
	
	public Account createAccount(String accountNumber, String balance);

	public void transferAccount(BankAccount accountSource, BankAccount accountTarget, String ammount);
	
	public void addOverdraft(BankAccount bankAccount, String ammount);
}
