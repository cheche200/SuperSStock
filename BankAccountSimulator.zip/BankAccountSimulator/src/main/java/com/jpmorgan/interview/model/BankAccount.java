package com.jpmorgan.interview.model;

import java.math.BigDecimal;
/** 
 * 
 * @author Jose Calderon
 *
 *This is the BEAN for BankAccoutn
 *
 */

public class BankAccount extends Account {
	


	private String accountNumber;
	private BigDecimal balance;
	private BigDecimal overDraftLimit;
	
	public BankAccount(String accountNumber, BigDecimal balance) {
		super(accountNumber, balance);
		this.accountNumber=accountNumber;
		this.balance=balance;
		this.overDraftLimit=new BigDecimal(0);
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public BigDecimal getBalance() {
		return balance;
	}
	
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	
	public BigDecimal getOverDraftLimit() {
		return overDraftLimit;
	}
	
	public void setOverDraftLimit(BigDecimal overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result + ((balance == null) ? 0 : balance.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankAccount other = (BankAccount) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (balance == null) {
			if (other.balance != null)
				return false;
		} else if (!balance.equals(other.balance))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Account number ****"+accountNumber.substring(accountNumber.length() - 3);
	}	
	
	

}
