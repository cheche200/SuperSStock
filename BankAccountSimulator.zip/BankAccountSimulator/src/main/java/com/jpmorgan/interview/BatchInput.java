package com.jpmorgan.interview;

import java.util.LinkedList;
import java.util.Queue;

import org.springframework.beans.factory.annotation.Autowired;

public class BatchInput {
	
	private Queue<String> batchQueue;
	
	@Autowired
	public BatchInput() {
		batchQueue=new LinkedList<>();
		batchQueue.offer("createAccount    A663537 1000");
		batchQueue.offer("createAccount    A828973 3000");
		batchQueue.offer("createAccount    A128933 2000");
		batchQueue.offer("transfer         A663537   A828973     100");
		batchQueue.offer("transfer         A128933   A663537     200");
		batchQueue.offer("addOverdraft    A663537 2500");
		batchQueue.offer("transfer         A663537   A828973     1500");
		batchQueue.offer("exit");
		
	}
	
	public String nextInputLine(){
		return batchQueue.poll();
	}
	

}
