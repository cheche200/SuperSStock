package com.jpmorgan.interview.model;

import java.math.BigDecimal;

public abstract class Account {
	
	public Account(String accountNumber, BigDecimal balance){
		
	}
	
	public abstract String getAccountNumber();
	
	public abstract void setAccountNumber(String accountNumber);
	
	public abstract BigDecimal getBalance();
	
	public abstract void setBalance(BigDecimal balance);
	
	public abstract BigDecimal getOverDraftLimit();
	
	public abstract void setOverDraftLimit(BigDecimal overdraftLimit);
	
	
	
}
